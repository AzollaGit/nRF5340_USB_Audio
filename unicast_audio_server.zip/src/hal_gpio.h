#ifndef INCLUDE_HAL_GPIO_H_
#define INCLUDE_HAL_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif
 
int hal_gpio_init(void);
 
#ifdef __cplusplus
}
#endif

#endif
