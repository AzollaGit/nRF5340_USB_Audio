# nRF5340_USB_Audio
基于 nRF5340 USB LE Audio 项目
